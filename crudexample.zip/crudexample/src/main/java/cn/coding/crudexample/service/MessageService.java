package cn.coding.crudexample.service;

import cn.coding.crudexample.entity.Message;
import cn.coding.crudexample.repository.MessageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MessageService {

    @Autowired
    private MessageRepository repository;

    public Message saveMessage(Message message){
        return repository.save(message);
    }
    public List<Message> saveMessages(List<Message> messages) {
        return repository.saveAll(messages);
    }
    public List<Message> getMessages(){
        return repository.findAll();
    }
    public Message getMessageById(int message_id) {
        return repository.findById(message_id).get();
    }
    public Message getMessageByContent(String content) {
        return repository.findByContent(content);
    }
    public String deleteMessage(int message_id) {
        repository.deleteById(message_id);
        return "message has been delete ! " + message_id;
    }
    public Message updateMessage(Message message){
        Message existingMessage = repository.findById(message.getMessage_id()).orElse(null);
        existingMessage.setContent(message.getContent());
        existingMessage.setType(message.getType());
        existingMessage.setTo_id(message.getTo_id());
        return repository.save(existingMessage);
    }
}
