package cn.coding.crudexample.controller;

import cn.coding.crudexample.entity.Message;
import cn.coding.crudexample.service.MessageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


import java.util.List;

@RestController
public class MessageController {

    @Autowired
    private MessageService messageService;

    @PostMapping("/addMessage")
    public Message addMessage(@RequestBody Message message) {
        return messageService.saveMessage(message);
    }

    @PostMapping("/addMessages")
    public List<Message> addMessages(@RequestBody List<Message> messages) {
        return messageService.saveMessages(messages);
    }
    @GetMapping("/messages")
    public List<Message> findAllMessages() {
        return messageService.getMessages();
    }
    @GetMapping("/messageById/{message_id}")
    public Message findMessageById(@PathVariable int message_id) {
        return messageService.getMessageById(message_id);
    }
    @GetMapping("/message/{content}")
    public Message findMessageByContent(@PathVariable String content) {
        return messageService.getMessageByContent(content);
    }
    @PutMapping("/update")
    public Message updateMessage(@RequestBody Message message) {
        return messageService.updateMessage(message);
    }
    @DeleteMapping("/delete/{message_id}")
    public String deleteMessage(int message_id){
        return messageService.deleteMessage(message_id);
    }
}